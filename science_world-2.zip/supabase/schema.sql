-- Run in Supabase SQL editor. Auth email template must include {{ .Token }} (OTP).
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  grade int, created_at timestamptz default now());

create table public.activation_codes (
  id uuid primary key default gen_random_uuid(),
  code_hash text unique not null,           -- sha256 of the code; plain code never stored
  duration_days int not null default 30,
  assigned_user uuid references auth.users,  -- optional: bind to one account
  code_expires_at timestamptz,
  revoked boolean default false,
  redeemed_by uuid references auth.users,
  redeemed_at timestamptz);

create table public.subscriptions (
  user_id uuid primary key references auth.users on delete cascade,
  expires_at timestamptz not null);

alter table public.profiles enable row level security;
alter table public.activation_codes enable row level security;  -- no policies = no client access
alter table public.subscriptions enable row level security;

create policy "own profile" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "own subscription read" on public.subscriptions for select using (auth.uid() = user_id);

create or replace function public.redeem_activation_code(p_code text)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare c public.activation_codes; new_exp timestamptz; cur timestamptz;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  select * into c from activation_codes
   where code_hash = encode(digest(trim(p_code), 'sha256'), 'hex') for update;
  if not found or c.revoked or c.redeemed_by is not null
     or (c.code_expires_at is not null and c.code_expires_at < now())
     or (c.assigned_user is not null and c.assigned_user <> auth.uid())
  then raise exception 'invalid code'; end if;
  select expires_at into cur from subscriptions where user_id = auth.uid();
  new_exp := greatest(coalesce(cur, now()), now()) + make_interval(days => c.duration_days);
  insert into subscriptions(user_id, expires_at) values (auth.uid(), new_exp)
    on conflict (user_id) do update set expires_at = excluded.expires_at;
  update activation_codes set redeemed_by = auth.uid(), redeemed_at = now() where id = c.id;
  return new_exp;
end $$;
revoke all on function public.redeem_activation_code(text) from public, anon;
grant execute on function public.redeem_activation_code(text) to authenticated;
-- TODO: rate-limit redeem attempts (attempt-log table) and add questions/books/packages tables with RLS.
