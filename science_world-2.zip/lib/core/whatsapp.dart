import 'package:url_launcher/url_launcher.dart';

const subscriptionMessage =
    'مرحبًا، أريد الاشتراك في تطبيق عالم العلوم. أرجو إرسال تفاصيل الدفع وطريقة تفعيل الاشتراك الشهري.';

Uri buildWhatsappUri(String number, [String message = subscriptionMessage]) {
  final digits = number.replaceAll(RegExp(r'[^0-9]'), '');
  return Uri.https('wa.me', '/$digits', {'text': message});
}

/// Opens WhatsApp. Returns false if it could not be launched.
Future<bool> openWhatsapp(String number) async {
  final uri = buildWhatsappUri(number);
  try {
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}
