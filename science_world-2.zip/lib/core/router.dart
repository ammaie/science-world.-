import 'package:go_router/go_router.dart';
import '../features/auth/auth_screens.dart';
import '../features/home/home_screens.dart';
import '../features/quiz/quiz_controller.dart';
import '../features/quiz/quiz_screens.dart';
import '../features/settings/settings_screen.dart';
import '../features/subscription/subscription_screens.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (_, __) => const SplashScreen()),
    GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
    GoRoute(path: '/verify', builder: (_, st) => VerifyEmailScreen(email: st.extra as String)),
    GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
    GoRoute(path: '/grades', builder: (_, __) => const GradeSelectScreen()),
    GoRoute(
        path: '/quiz',
        builder: (_, st) {
          final m = st.extra as Map<String, Object?>;
          return QuizScreen(grade: m['grade'] as int, subject: m['subject'] as String);
        }),
    GoRoute(path: '/result', builder: (_, st) => ResultScreen(result: st.extra as QuizResult)),
    GoRoute(path: '/subscription', builder: (_, __) => const SubscriptionScreen()),
    GoRoute(path: '/activate', builder: (_, __) => const ActivateCodeScreen()),
    GoRoute(path: '/settings', builder: (_, __) => const SettingsScreen()),
  ],
);
