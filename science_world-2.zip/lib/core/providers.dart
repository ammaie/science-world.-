import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/local/app_database.dart';
import '../features/audio/sound_service.dart';

final databaseProvider = FutureProvider<AppDatabase>((ref) => AppDatabase.open());

final soundProvider = Provider<SoundService>((ref) {
  final s = SoundService();
  ref.onDispose(s.dispose);
  return s;
});
