import 'package:flutter/foundation.dart';

/// Technical logging without sensitive data (no emails, codes, tokens).
class Log {
  static void e(String where, Object error, [StackTrace? st]) {
    if (kDebugMode) debugPrint('[ERR][$where] ${error.runtimeType}');
    // TODO: forward to a crash reporter with PII scrubbing.
  }

  static void i(String msg) {
    if (kDebugMode) debugPrint('[INFO] $msg');
  }
}
