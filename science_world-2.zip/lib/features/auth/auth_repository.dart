import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/config.dart';

class AuthFailure implements Exception {
  const AuthFailure(this.message);
  final String message;
}

abstract class AuthRepository {
  bool get isSignedIn;
  Future<void> signUp(String email, String password);
  Future<void> verifyEmail(String email, String code);
  Future<void> resendCode(String email);
  Future<void> signIn(String email, String password);
  Future<void> resetPassword(String email);
  Future<void> signOut();
}

/// Supabase Auth: passwords are hashed server-side; email OTP is sent by
/// the service (template must contain {{ .Token }}). No code is ever
/// shown in-app or logged.
class SupabaseAuthRepository implements AuthRepository {
  SupabaseClient get _c => Supabase.instance.client;

  @override
  bool get isSignedIn => _c.auth.currentSession != null;

  Future<T> _guard<T>(Future<T> Function() f) async {
    if (!AppConfig.isBackendConfigured) {
      throw const AuthFailure('الخدمة غير مهيأة بعد. راجع إعداد الخادم في README.');
    }
    try {
      return await f();
    } on AuthException catch (e) {
      throw AuthFailure(_arabic(e.message));
    } catch (_) {
      throw const AuthFailure('تعذّر الاتصال. تحقق من الإنترنت وحاول مجددًا.');
    }
  }

  String _arabic(String m) {
    final s = m.toLowerCase();
    if (s.contains('invalid login')) return 'البريد أو كلمة المرور غير صحيحة.';
    if (s.contains('not confirmed')) return 'يجب التحقق من البريد أولًا.';
    if (s.contains('expired') || s.contains('invalid')) return 'الرمز غير صالح أو منتهي.';
    if (s.contains('rate') || s.contains('too many')) return 'محاولات كثيرة، انتظر قليلًا.';
    if (s.contains('already')) return 'هذا البريد مسجّل مسبقًا.';
    return 'حدث خطأ. حاول مرة أخرى.';
  }

  @override
  Future<void> signUp(String email, String password) =>
      _guard(() => _c.auth.signUp(email: email, password: password));

  @override
  Future<void> verifyEmail(String email, String code) => _guard(
      () => _c.auth.verifyOTP(type: OtpType.signup, email: email, token: code));

  @override
  Future<void> resendCode(String email) =>
      _guard(() => _c.auth.resend(type: OtpType.signup, email: email));

  @override
  Future<void> signIn(String email, String password) =>
      _guard(() => _c.auth.signInWithPassword(email: email, password: password));

  @override
  Future<void> resetPassword(String email) =>
      _guard(() => _c.auth.resetPasswordForEmail(email));

  @override
  Future<void> signOut() => _guard(() => _c.auth.signOut());
}

final authRepositoryProvider =
    Provider<AuthRepository>((_) => SupabaseAuthRepository());
