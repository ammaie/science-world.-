import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'auth_repository.dart';

bool isValidEmail(String v) => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim());

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginState();
}

class _LoginState extends ConsumerState<LoginScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _register = false, _busy = false;
  String? _error;

  Future<void> _submit() async {
    final email = _email.text.trim();
    if (!isValidEmail(email)) return setState(() => _error = 'أدخل بريدًا إلكترونيًا صحيحًا.');
    if (_pass.text.length < 8) return setState(() => _error = 'كلمة المرور 8 أحرف على الأقل.');
    setState(() { _busy = true; _error = null; });
    final repo = ref.read(authRepositoryProvider);
    try {
      if (_register) {
        await repo.signUp(email, _pass.text);
        if (mounted) context.go('/verify', extra: email);
      } else {
        await repo.signIn(email, _pass.text);
        if (mounted) context.go('/home');
      }
    } on AuthFailure catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(_register ? 'إنشاء حساب' : 'تسجيل الدخول')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          TextField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.email],
              decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
          const SizedBox(height: 12),
          TextField(
              controller: _pass,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'كلمة المرور')),
          if (_error != null)
            Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(_error!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 20),
          FilledButton(
              onPressed: _busy ? null : _submit,
              child: _busy
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(_register ? 'إنشاء الحساب' : 'دخول')),
          TextButton(
              onPressed: () => setState(() => _register = !_register),
              child: Text(_register ? 'لدي حساب' : 'إنشاء حساب جديد')),
          if (!_register)
            TextButton(
                onPressed: () async {
                  final email = _email.text.trim();
                  if (!isValidEmail(email)) {
                    setState(() => _error = 'أدخل بريدك أولًا لاستعادة كلمة المرور.');
                    return;
                  }
                  try {
                    await ref.read(authRepositoryProvider).resetPassword(email);
                    if (mounted) setState(() => _error = 'إن كان البريد مسجّلًا فستصلك رسالة الاستعادة.');
                  } on AuthFailure catch (e) {
                    if (mounted) setState(() => _error = e.message);
                  }
                },
                child: const Text('نسيت كلمة المرور؟')),
        ]),
      );
}

class VerifyEmailScreen extends ConsumerStatefulWidget {
  const VerifyEmailScreen({super.key, required this.email});
  final String email;
  @override
  ConsumerState<VerifyEmailScreen> createState() => _VerifyState();
}

class _VerifyState extends ConsumerState<VerifyEmailScreen> {
  final _code = TextEditingController();
  String? _msg;
  bool _busy = false;
  int _cooldown = 60;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _cooldown = 60;
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_cooldown <= 1) t.cancel();
      if (mounted) setState(() => _cooldown--);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _verify() async {
    setState(() { _busy = true; _msg = null; });
    try {
      await ref.read(authRepositoryProvider).verifyEmail(widget.email, _code.text.trim());
      if (mounted) context.go('/home');
    } on AuthFailure catch (e) {
      if (mounted) setState(() => _msg = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('التحقق من البريد')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('أرسلنا رمز تحقق إلى بريدك. أدخله لتفعيل الحساب.'),
          const SizedBox(height: 16),
          TextField(
              controller: _code,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              decoration: const InputDecoration(labelText: 'رمز التحقق')),
          if (_msg != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_msg!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 20),
          FilledButton(onPressed: _busy ? null : _verify, child: const Text('تحقق')),
          TextButton(
              onPressed: _cooldown > 0
                  ? null
                  : () async {
                      try {
                        await ref.read(authRepositoryProvider).resendCode(widget.email);
                        _startTimer();
                      } on AuthFailure catch (e) {
                        if (mounted) setState(() => _msg = e.message);
                      }
                    },
              child: Text(_cooldown > 0 ? 'إعادة الإرسال بعد $_cooldown ث' : 'إعادة إرسال الرمز')),
        ]),
      );
}
