import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/config.dart';
import '../../core/whatsapp.dart';
import '../../data/settings_store.dart';

class WhatsappButton extends ConsumerWidget {
  const WhatsappButton({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => OutlinedButton.icon(
        icon: const Icon(Icons.chat),
        label: const Text('التواصل لتفعيل الاشتراك'),
        onPressed: () async {
          final ok = await openWhatsapp(ref.read(settingsProvider).whatsappNumber);
          if (!ok && context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تعذّر فتح واتساب. تأكد من تثبيته.')));
          }
        },
      );
}

class SubscriptionScreen extends StatelessWidget {
  const SubscriptionScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('الاشتراك المميز')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const Card(
              child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('الباقة الشهرية', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('المدة: شهر واحد'),
              Text('السعر: يُحدَّد عند التواصل (لم يُضبط سعر داخل التطبيق بعد)'),
              SizedBox(height: 8),
              Text('المزايا: الأسئلة المدفوعة، المساعد الذكي، التنزيلات الإضافية — حسب ما يُنشر من الخادم.'),
            ]),
          )),
          const SizedBox(height: 12),
          const Text('الخطوات: تواصل معنا ← ادفع ← نتحقق من الدفع ← نرسل لك كود تفعيل ← أدخله في صفحة التفعيل.\nالتواصل عبر واتساب لا يفعّل الاشتراك تلقائيًا.'),
          const SizedBox(height: 16),
          const WhatsappButton(),
          const SizedBox(height: 8),
          FilledButton(onPressed: () => context.push('/activate'), child: const Text('لدي كود تفعيل')),
        ]),
      );
}

class ActivateCodeScreen extends StatefulWidget {
  const ActivateCodeScreen({super.key});
  @override
  State<ActivateCodeScreen> createState() => _ActivateState();
}

class _ActivateState extends State<ActivateCodeScreen> {
  final _code = TextEditingController();
  String? _msg;
  bool _busy = false, _ok = false;

  Future<void> _redeem() async {
    if (!AppConfig.isBackendConfigured) {
      setState(() => _msg = 'الخدمة غير مهيأة بعد.');
      return;
    }
    setState(() { _busy = true; _msg = null; });
    try {
      // Verification happens on the server (RPC); nothing is trusted locally.
      final res = await Supabase.instance.client
          .rpc('redeem_activation_code', params: {'p_code': _code.text.trim()});
      setState(() { _ok = true; _msg = 'تم التفعيل. ينتهي الاشتراك في: $res'; });
    } on PostgrestException {
      setState(() => _msg = 'الكود غير صالح أو مستخدم أو منتهي.');
    } catch (_) {
      setState(() => _msg = 'يلزم اتصال بالإنترنت لتفعيل الكود.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تفعيل الاشتراك')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          TextField(controller: _code, textAlign: TextAlign.center, decoration: const InputDecoration(labelText: 'كود التفعيل')),
          if (_msg != null)
            Padding(padding: const EdgeInsets.only(top: 12), child: Text(_msg!, style: TextStyle(color: _ok ? Colors.green : Colors.red))),
          const SizedBox(height: 16),
          FilledButton(onPressed: _busy ? null : _redeem, child: const Text('تفعيل')),
          const SizedBox(height: 8),
          const WhatsappButton(),
        ]),
      );
}
