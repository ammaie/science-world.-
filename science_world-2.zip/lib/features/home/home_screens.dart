import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/config.dart';
import '../../core/theme.dart';
import '../../data/settings_store.dart';
import '../curriculum/curriculum.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashState();
}

class _SplashState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 900), () {
      if (!mounted) return;
      final signedIn = AppConfig.isBackendConfigured &&
          Supabase.instance.client.auth.currentSession != null;
      context.go(signedIn ? '/home' : '/login');
    });
  }

  @override
  Widget build(BuildContext context) => const Scaffold(
        backgroundColor: AppColors.navy,
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.science, size: 84, color: Colors.white),
            SizedBox(height: 12),
            Text('عالم العلوم', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
            Text('Science World', style: TextStyle(color: Colors.white70)),
          ]),
        ),
      );
}

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final grade = grades.where((g) => g.id == s.grade).firstOrNull;
    return Scaffold(
      appBar: AppBar(title: const Text('عالم العلوم'), actions: [
        IconButton(tooltip: 'الإعدادات', icon: const Icon(Icons.settings), onPressed: () => context.push('/settings')),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (!AppConfig.isBackendConfigured)
          const Card(child: Padding(padding: EdgeInsets.all(12), child: Text('الخادم غير مهيأ: التسجيل والاشتراك لن يعملا حتى إعداد Supabase (انظر README).'))),
        Card(
          child: ListTile(
            leading: const Icon(Icons.school, color: AppColors.blue),
            title: Text(grade?.name ?? 'اختر صفك الدراسي'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => context.push('/grades'),
          ),
        ),
        if (grade != null) ...[
          const Padding(padding: EdgeInsets.fromLTRB(4, 16, 4, 8), child: Text('المواد', style: TextStyle(fontWeight: FontWeight.bold))),
          for (final sub in subjectsFor(grade.id))
            Card(
              child: ListTile(
                title: Text(sub.name),
                subtitle: sub.verified ? null : const Text('بانتظار التحقق من المنهاج'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => context.push('/quiz', extra: {'grade': grade.id, 'subject': sub.name}),
              ),
            ),
        ],
        const SizedBox(height: 12),
        FilledButton(onPressed: () => context.push('/subscription'), child: const Text('الاشتراك المميز')),
      ]),
    );
  }
}

class GradeSelectScreen extends ConsumerWidget {
  const GradeSelectScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('اختيار الصف')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          for (final g in grades)
            Card(
              child: ListTile(
                title: Text(g.name),
                onTap: () {
                  final n = ref.read(settingsProvider.notifier);
                  n.update(ref.read(settingsProvider).copyWith(grade: g.id));
                  context.pop();
                },
              ),
            ),
        ]),
      );
}
