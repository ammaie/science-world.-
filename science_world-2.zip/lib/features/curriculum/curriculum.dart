/// Grades and subjects. NOTE: the subject list below is a working
/// placeholder, flagged `verified: false` until each grade's list is
/// confirmed against curricula.moed.gov.sy. The UI shows «بانتظار التحقق».
class Grade {
  const Grade(this.id, this.name);
  final int id;
  final String name;
}

class Subject {
  const Subject(this.name, {this.verified = false});
  final String name;
  final bool verified;
}

const grades = [
  Grade(9, 'الصف التاسع'),
  Grade(10, 'الصف العاشر'),
  Grade(11, 'الصف الحادي عشر العلمي'),
  Grade(12, 'البكالوريا العلمي'),
];

const _common = [
  Subject('الرياضيات'),
  Subject('الفيزياء'),
  Subject('الكيمياء'),
  Subject('العلوم الطبيعية'),
  Subject('اللغة العربية'),
  Subject('اللغة الإنجليزية'),
  Subject('اللغة الفرنسية'),
  Subject('التربية الدينية'),
];

List<Subject> subjectsFor(int grade) => _common;
