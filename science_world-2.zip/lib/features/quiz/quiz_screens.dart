import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../data/models/question.dart';
import '../../data/settings_store.dart';
import '../audio/sound_service.dart';
import 'quiz_controller.dart';

class QuizScreen extends ConsumerStatefulWidget {
  const QuizScreen({super.key, required this.grade, required this.subject});
  final int grade;
  final String subject;
  @override
  ConsumerState<QuizScreen> createState() => _QuizState();
}

class _QuizState extends ConsumerState<QuizScreen> {
  QuizController? _quiz;
  bool _loading = true;
  String? _selected;
  final _text = TextEditingController();
  late final String _sessionId = DateTime.now().microsecondsSinceEpoch.toString();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = await ref.read(databaseProvider.future);
    // Debug builds only: seed clearly-labelled technical samples so the flow can be tested.
    if (kDebugMode && await db.questionCount() == 0) {
      final raw = jsonDecode(await rootBundle.loadString('assets/sample/sample_questions.json')) as List;
      await db.upsertQuestions(
          raw.map((e) => Question.fromJson(e as Map<String, dynamic>)).toList(),
          package: 'sample');
    }
    final qs = await db.questionsFor(grade: widget.grade, subject: widget.subject);
    if (!mounted) return;
    setState(() {
      _quiz = qs.isEmpty ? null : QuizController(qs);
      _loading = false;
    });
  }

  Future<void> _answer(String a) async {
    final quiz = _quiz!;
    if (quiz.currentAnswered) return;
    final state = quiz.submit(a);
    setState(() {});
    final settings = ref.read(settingsProvider);
    if (state != AnswerState.selfReview) {
      ref.read(soundProvider).play(
          state == AnswerState.correct ? Sfx.correct : Sfx.wrong, settings);
    }
    final db = await ref.read(databaseProvider.future);
    await db.saveAttempt(_sessionId, quiz.current.id, a,
        state == AnswerState.selfReview ? null : state == AnswerState.correct);
  }

  Future<void> _next() async {
    final quiz = _quiz!;
    if (!quiz.isLast) {
      setState(() { quiz.next(); _selected = null; _text.clear(); });
      return;
    }
    final r = quiz.result();
    final db = await ref.read(databaseProvider.future);
    await db.saveSession(_sessionId, widget.subject, widget.grade, r.total, r.correct, r.wrong, r.skipped);
    ref.read(soundProvider).play(Sfx.finish, ref.read(settingsProvider));
    if (mounted) context.pushReplacement('/result', extra: r);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final quiz = _quiz;
    if (quiz == null) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.subject)),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text('لا توجد أسئلة منزّلة لهذه المادة بعد.\nستظهر هنا عند نشر حزم الأسئلة من الخادم.',
                textAlign: TextAlign.center),
          ),
        ),
      );
    }
    final q = quiz.current;
    final answered = quiz.currentAnswered;
    final state = quiz.stateOf(quiz.index);
    return Scaffold(
      appBar: AppBar(title: Text('${quiz.index + 1} / ${quiz.questions.length}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (q.origin == QuestionOrigin.sample)
          const Card(child: Padding(padding: EdgeInsets.all(8), child: Text('عينة تقنية لاختبار التطبيق — ليست سؤالًا رسميًا'))),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(q.text, style: const TextStyle(fontSize: 18)))),
        const SizedBox(height: 12),
        ..._input(q, answered),
        const SizedBox(height: 12),
        if (answered) _Feedback(q: q, state: state, animate: ref.watch(settingsProvider).animate),
        const SizedBox(height: 12),
        if (answered)
          FilledButton(onPressed: _next, child: Text(quiz.isLast ? 'إنهاء الاختبار' : 'التالي')),
      ]),
    );
  }

  List<Widget> _input(Question q, bool answered) {
    switch (q.type) {
      case QuestionType.mcq:
        return [
          for (var i = 0; i < q.options.length; i++)
            _OptionTile(
              label: q.options[i],
              onTap: answered ? null : () { setState(() => _selected = '$i'); _answer('$i'); },
              color: _tileColor(answered, '$i', q.correct),
            )
        ];
      case QuestionType.trueFalse:
        return [
          for (final e in const {'true': 'صح', 'false': 'خطأ'}.entries)
            _OptionTile(
              label: e.value,
              onTap: answered ? null : () { setState(() => _selected = e.key); _answer(e.key); },
              color: _tileColor(answered, e.key, q.correct),
            )
        ];
      default:
        return [
          TextField(
            controller: _text,
            enabled: !answered,
            keyboardType: q.type == QuestionType.numeric ? TextInputType.number : TextInputType.text,
            decoration: const InputDecoration(labelText: 'إجابتك'),
          ),
          const SizedBox(height: 8),
          if (!answered) FilledButton(onPressed: () => _answer(_text.text), child: const Text('تأكيد')),
        ];
    }
  }

  Color? _tileColor(bool answered, String value, String? correct) {
    if (!answered) return null;
    if (value == correct) return AppColors.success.withOpacity(0.18);
    if (value == _selected) return AppColors.danger.withOpacity(0.18);
    return null;
  }
}

class _OptionTile extends StatelessWidget {
  const _OptionTile({required this.label, required this.onTap, this.color});
  final String label;
  final VoidCallback? onTap;
  final Color? color;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Material(
          color: color ?? Colors.white,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Align(alignment: AlignmentDirectional.centerStart, child: Text(label, style: const TextStyle(fontSize: 16)))),
          ),
        ),
      );
}

class _Feedback extends StatelessWidget {
  const _Feedback({required this.q, required this.state, required this.animate});
  final Question q;
  final AnswerState state;
  final bool animate;
  @override
  Widget build(BuildContext context) {
    final ok = state == AnswerState.correct;
    final review = state == AnswerState.selfReview;
    final color = review ? AppColors.blue : (ok ? AppColors.success : AppColors.danger);
    final msg = review
        ? 'قارن إجابتك بمعيار التصحيح.'
        : (ok ? 'إجابة صحيحة، أحسنت!' : 'الإجابة غير صحيحة، حاول مرة أخرى.');
    final body = Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(review ? Icons.info : (ok ? Icons.check_circle : Icons.cancel), color: color),
            const SizedBox(width: 8),
            Expanded(child: Text(msg, style: TextStyle(color: color, fontWeight: FontWeight.bold))),
          ]),
          if (!ok && !review && q.correct != null)
            Text('الإجابة الصحيحة: ${q.type == QuestionType.mcq ? q.options[int.parse(q.correct!)] : (q.correct == 'true' ? 'صح' : q.correct == 'false' ? 'خطأ' : q.correct)}'),
          if (review && q.rubric != null) Text(q.rubric!),
          if (q.explanation != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(q.explanation!)),
        ]),
      ),
    );
    if (!animate) return body;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.95, end: 1),
      duration: const Duration(milliseconds: 220),
      builder: (_, v, child) => Transform.scale(scale: v, child: child),
      child: body,
    );
  }
}

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.result});
  final QuizResult result;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('نتيجة الاختبار')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('${result.percent.toStringAsFixed(0)}%',
                style: const TextStyle(fontSize: 56, fontWeight: FontWeight.bold, color: AppColors.blue)),
            const SizedBox(height: 16),
            Text('صحيحة: ${result.correct}   خاطئة: ${result.wrong}   متروكة: ${result.skipped}'),
            const SizedBox(height: 32),
            FilledButton(onPressed: () => context.go('/home'), child: const Text('العودة للرئيسية')),
          ]),
        ),
      );
}
