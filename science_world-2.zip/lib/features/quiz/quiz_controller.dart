import '../../data/models/question.dart';

enum AnswerState { unanswered, correct, wrong, selfReview }

class QuizResult {
  const QuizResult(this.total, this.correct, this.wrong, this.skipped);
  final int total, correct, wrong, skipped;
  double get percent => total == 0 ? 0 : correct * 100 / total;
}

/// Pure Dart quiz logic (unit-testable, no Flutter dependency).
class QuizController {
  QuizController(this.questions);
  final List<Question> questions;
  final Map<int, String> _answers = {};
  final Map<int, AnswerState> _states = {};
  int index = 0;

  Question get current => questions[index];
  bool get isLast => index >= questions.length - 1;
  AnswerState stateOf(int i) => _states[i] ?? AnswerState.unanswered;
  bool get currentAnswered => stateOf(index) != AnswerState.unanswered;

  /// Locks the first answer for a question; repeated taps are ignored.
  AnswerState submit(String answer) {
    if (currentAnswered) return stateOf(index);
    final r = current.check(answer);
    final s = r == null
        ? AnswerState.selfReview
        : (r ? AnswerState.correct : AnswerState.wrong);
    _answers[index] = answer;
    _states[index] = s;
    return s;
  }

  String? answerOf(int i) => _answers[i];

  void next() {
    if (!isLast) index++;
  }

  QuizResult result() {
    var c = 0, w = 0, sk = 0;
    for (var i = 0; i < questions.length; i++) {
      switch (stateOf(i)) {
        case AnswerState.correct: c++;
        case AnswerState.wrong: w++;
        case AnswerState.unanswered: sk++;
        case AnswerState.selfReview: break;
      }
    }
    return QuizResult(questions.length, c, w, sk);
  }
}
