import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import '../../core/logger.dart';
import '../../data/settings_store.dart';

enum Sfx { correct, wrong, finish }

/// Local, preloaded effects. Never waits on the network; rapid taps
/// cannot stack sounds because a new play stops the previous one and
/// calls within [_minGap] are dropped.
class SoundService {
  SoundService() {
    _player.setPlayerMode(PlayerMode.lowLatency);
  }
  final AudioPlayer _player = AudioPlayer();
  static const _minGap = Duration(milliseconds: 150);
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  static const _files = {
    Sfx.correct: 'sounds/correct.wav',
    Sfx.wrong: 'sounds/wrong.wav',
    Sfx.finish: 'sounds/finish.wav',
  };

  Future<void> play(Sfx sfx, AppSettings s) async {
    if (s.haptics) {
      sfx == Sfx.wrong ? HapticFeedback.lightImpact() : HapticFeedback.selectionClick();
    }
    if (!s.soundOn) return;
    final now = DateTime.now();
    if (now.difference(_last) < _minGap) return;
    _last = now;
    try {
      await _player.stop();
      await _player.setVolume(s.volume);
      await _player.play(AssetSource(_files[sfx]!));
    } catch (e, st) {
      Log.e('sound', e, st);
    }
  }

  Future<void> dispose() => _player.dispose();
}
