import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/settings_store.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(children: [
        SwitchListTile(title: const Text('المؤثرات الصوتية'), value: s.soundOn, onChanged: (v) => n.update(s.copyWith(soundOn: v))),
        ListTile(
          title: const Text('مستوى صوت المؤثرات'),
          subtitle: Slider(value: s.volume, onChanged: s.soundOn ? (v) => n.update(s.copyWith(volume: v)) : null),
        ),
        SwitchListTile(title: const Text('الاهتزاز'), value: s.haptics, onChanged: (v) => n.update(s.copyWith(haptics: v))),
        SwitchListTile(title: const Text('الرسوم المتحركة'), value: s.animations, onChanged: (v) => n.update(s.copyWith(animations: v))),
        SwitchListTile(title: const Text('الوضع الهادئ (يقلل الحركة)'), value: s.calmMode, onChanged: (v) => n.update(s.copyWith(calmMode: v))),
        ListTile(
          title: const Text('حجم النص'),
          subtitle: Slider(min: 0.85, max: 1.4, divisions: 11, value: s.textScale, onChanged: (v) => n.update(s.copyWith(textScale: v))),
        ),
        ListTile(
          title: const Text('رقم واتساب للتواصل'),
          subtitle: Text('+${s.whatsappNumber}'),
          trailing: const Icon(Icons.edit),
          onTap: () async {
            final c = TextEditingController(text: s.whatsappNumber);
            final v = await showDialog<String>(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text('رقم واتساب (أرقام فقط مع رمز الدولة)'),
                content: TextField(controller: c, keyboardType: TextInputType.phone),
                actions: [TextButton(onPressed: () => Navigator.pop(context, c.text), child: const Text('حفظ'))],
              ),
            );
            final digits = v?.replaceAll(RegExp(r'[^0-9]'), '') ?? '';
            if (digits.length >= 8) n.update(s.copyWith(whatsappNumber: digits));
          },
        ),
      ]),
    );
  }
}
