enum QuestionType { mcq, trueFalse, fillBlank, numeric, written }

enum Difficulty { easy, medium, hard }

/// official = from a verified official source; practice = training question.
enum QuestionOrigin { official, practice, sample }

class Question {
  const Question({
    required this.id,
    required this.grade,
    required this.subject,
    required this.lesson,
    required this.type,
    required this.difficulty,
    required this.text,
    this.options = const [],
    this.correct,
    this.rubric,
    this.explanation,
    this.source,
    this.origin = QuestionOrigin.practice,
    this.isPremium = false,
  });

  final String id;
  final int grade;
  final String subject;
  final String lesson;
  final QuestionType type;
  final Difficulty difficulty;
  final String text;
  final List<String> options;

  /// MCQ: option index as string; trueFalse: 'true'/'false'; others: text/number.
  final String? correct;
  final String? rubric;
  final String? explanation;
  final String? source;
  final QuestionOrigin origin;
  final bool isPremium;

  /// Questions lacking a correct answer or rubric must never be published.
  bool get isComplete => type == QuestionType.written
      ? (rubric?.trim().isNotEmpty ?? false)
      : (correct?.trim().isNotEmpty ?? false);

  /// Auto-gradable types only. Written questions return null (self-review).
  bool? check(String answer) {
    if (type == QuestionType.written || correct == null) return null;
    final a = answer.trim().toLowerCase();
    final c = correct!.trim().toLowerCase();
    if (type == QuestionType.numeric) {
      final x = double.tryParse(a);
      final y = double.tryParse(c);
      if (x == null || y == null) return false;
      return (x - y).abs() < 1e-6;
    }
    return a == c;
  }

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id'] as String,
        grade: j['grade'] as int,
        subject: j['subject'] as String,
        lesson: (j['lesson'] ?? '') as String,
        type: QuestionType.values.byName(j['type'] as String),
        difficulty: Difficulty.values.byName((j['difficulty'] ?? 'medium') as String),
        text: j['text'] as String,
        options: List<String>.from(j['options'] ?? const []),
        correct: j['correct']?.toString(),
        rubric: j['rubric'] as String?,
        explanation: j['explanation'] as String?,
        source: j['source'] as String?,
        origin: QuestionOrigin.values.byName((j['origin'] ?? 'practice') as String),
        isPremium: (j['is_premium'] ?? false) as bool,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'grade': grade,
        'subject': subject,
        'lesson': lesson,
        'type': type.name,
        'difficulty': difficulty.name,
        'text': text,
        'options': options,
        'correct': correct,
        'rubric': rubric,
        'explanation': explanation,
        'source': source,
        'origin': origin.name,
        'is_premium': isPremium,
      };
}
