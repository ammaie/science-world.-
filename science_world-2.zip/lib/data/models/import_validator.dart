import 'question.dart';

class ImportReport {
  ImportReport(this.accepted, this.duplicates, this.incomplete, this.errors);
  final List<Question> accepted;
  final List<String> duplicates;
  final List<String> incomplete;
  final List<String> errors;
}

/// Validates a structured question file before publishing:
/// detects duplicates, missing answers, and malformed rows.
ImportReport validateQuestions(List<Map<String, dynamic>> rows,
    {Set<String> existingIds = const {}}) {
  final accepted = <Question>[];
  final dups = <String>[];
  final incomplete = <String>[];
  final errors = <String>[];
  final seenIds = {...existingIds};
  final seenText = <String>{};
  for (var i = 0; i < rows.length; i++) {
    try {
      final q = Question.fromJson(rows[i]);
      final key = '${q.grade}|${q.subject}|${q.text.trim()}';
      if (seenIds.contains(q.id) || seenText.contains(key)) {
        dups.add(q.id);
        continue;
      }
      if (!q.isComplete) {
        incomplete.add(q.id);
        continue;
      }
      if (q.origin == QuestionOrigin.official && (q.source?.isEmpty ?? true)) {
        errors.add('${q.id}: سؤال رسمي بلا مصدر موثّق');
        continue;
      }
      seenIds.add(q.id);
      seenText.add(key);
      accepted.add(q);
    } catch (e) {
      errors.add('صف ${i + 1}: بيانات غير صالحة');
    }
  }
  return ImportReport(accepted, dups, incomplete, errors);
}
