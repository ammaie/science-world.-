import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/config.dart';

class AppSettings {
  const AppSettings({
    this.soundOn = true,
    this.volume = 0.7,
    this.haptics = true,
    this.animations = true,
    this.calmMode = false,
    this.textScale = 1.0,
    this.whatsappNumber = AppConfig.defaultWhatsappNumber,
    this.grade,
  });
  final bool soundOn;
  final double volume;
  final bool haptics;
  final bool animations;
  final bool calmMode;
  final double textScale;
  final String whatsappNumber;
  final int? grade;

  bool get animate => animations && !calmMode;

  AppSettings copyWith({bool? soundOn, double? volume, bool? haptics, bool? animations,
          bool? calmMode, double? textScale, String? whatsappNumber, int? grade}) =>
      AppSettings(
        soundOn: soundOn ?? this.soundOn,
        volume: volume ?? this.volume,
        haptics: haptics ?? this.haptics,
        animations: animations ?? this.animations,
        calmMode: calmMode ?? this.calmMode,
        textScale: textScale ?? this.textScale,
        whatsappNumber: whatsappNumber ?? this.whatsappNumber,
        grade: grade ?? this.grade,
      );
}

final prefsProvider = Provider<SharedPreferences>((_) => throw UnimplementedError());

final settingsProvider =
    NotifierProvider<SettingsNotifier, AppSettings>(SettingsNotifier.new);

class SettingsNotifier extends Notifier<AppSettings> {
  late SharedPreferences _p;

  @override
  AppSettings build() {
    _p = ref.watch(prefsProvider);
    return AppSettings(
      soundOn: _p.getBool('soundOn') ?? true,
      volume: _p.getDouble('volume') ?? 0.7,
      haptics: _p.getBool('haptics') ?? true,
      animations: _p.getBool('animations') ?? true,
      calmMode: _p.getBool('calmMode') ?? false,
      textScale: _p.getDouble('textScale') ?? 1.0,
      whatsappNumber: _p.getString('whatsapp') ?? AppConfig.defaultWhatsappNumber,
      grade: _p.getInt('grade'),
    );
  }

  void update(AppSettings s) {
    state = s;
    _p.setBool('soundOn', s.soundOn);
    _p.setDouble('volume', s.volume);
    _p.setBool('haptics', s.haptics);
    _p.setBool('animations', s.animations);
    _p.setBool('calmMode', s.calmMode);
    _p.setDouble('textScale', s.textScale);
    _p.setString('whatsapp', s.whatsappNumber);
    if (s.grade != null) _p.setInt('grade', s.grade!);
  }
}
