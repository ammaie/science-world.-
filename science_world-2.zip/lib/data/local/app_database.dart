import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/question.dart';

/// Local SQLite store: downloaded questions, attempts, progress,
/// favorites, bookmarks. `synced = 0` rows are pushed when online;
/// merges are append-only so local answers are never overwritten.
class AppDatabase {
  AppDatabase._(this._db);
  final Database _db;

  static Future<AppDatabase> open({String? path}) async {
    final dbPath = path ?? p.join(await getDatabasesPath(), 'science_world.db');
    final db = await openDatabase(dbPath, version: 1, onCreate: (db, v) async {
      await db.execute('''CREATE TABLE questions(
        id TEXT PRIMARY KEY, grade INTEGER, subject TEXT, lesson TEXT,
        premium INTEGER, json TEXT, package TEXT, updated_at TEXT)''');
      await db.execute('''CREATE TABLE attempts(
        id INTEGER PRIMARY KEY AUTOINCREMENT, question_id TEXT, answer TEXT,
        correct INTEGER, session_id TEXT, created_at TEXT, synced INTEGER DEFAULT 0)''');
      await db.execute('''CREATE TABLE sessions(
        id TEXT PRIMARY KEY, subject TEXT, grade INTEGER, total INTEGER,
        correct INTEGER, wrong INTEGER, skipped INTEGER, created_at TEXT,
        synced INTEGER DEFAULT 0)''');
      await db.execute('CREATE TABLE favorites(question_id TEXT PRIMARY KEY)');
      await db.execute('''CREATE TABLE bookmarks(
        id INTEGER PRIMARY KEY AUTOINCREMENT, book_id TEXT, page INTEGER, note TEXT)''');
      await db.execute('''CREATE TABLE downloads(
        package TEXT PRIMARY KEY, bytes INTEGER, status TEXT, updated_at TEXT)''');
    });
    return AppDatabase._(db);
  }

  Future<void> upsertQuestions(List<Question> qs, {String package = 'local'}) async {
    final batch = _db.batch();
    final now = DateTime.now().toUtc().toIso8601String();
    for (final q in qs) {
      batch.insert(
        'questions',
        {
          'id': q.id,
          'grade': q.grade,
          'subject': q.subject,
          'lesson': q.lesson,
          'premium': q.isPremium ? 1 : 0,
          'json': jsonEncode(q.toJson()),
          'package': package,
          'updated_at': now,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<List<Question>> questionsFor({required int grade, required String subject}) async {
    final rows = await _db.query('questions',
        where: 'grade = ? AND subject = ?', whereArgs: [grade, subject]);
    return rows
        .map((r) => Question.fromJson(jsonDecode(r['json'] as String) as Map<String, dynamic>))
        .toList();
  }

  Future<int> questionCount() async =>
      Sqflite.firstIntValue(await _db.rawQuery('SELECT COUNT(*) FROM questions')) ?? 0;

  Future<void> saveAttempt(String sessionId, String questionId, String answer, bool? correct) =>
      _db.insert('attempts', {
        'question_id': questionId,
        'answer': answer,
        'correct': correct == null ? null : (correct ? 1 : 0),
        'session_id': sessionId,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

  Future<void> saveSession(String id, String subject, int grade, int total, int correct,
          int wrong, int skipped) =>
      _db.insert(
          'sessions',
          {
            'id': id,
            'subject': subject,
            'grade': grade,
            'total': total,
            'correct': correct,
            'wrong': wrong,
            'skipped': skipped,
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
          conflictAlgorithm: ConflictAlgorithm.ignore);

  Future<Map<String, Object?>?> lastSession() async {
    final r = await _db.query('sessions', orderBy: 'created_at DESC', limit: 1);
    return r.isEmpty ? null : r.first;
  }

  Future<void> close() => _db.close();
}
