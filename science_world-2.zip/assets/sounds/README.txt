Original sound effects generated programmatically (sine tones) for this project; no third-party audio.
