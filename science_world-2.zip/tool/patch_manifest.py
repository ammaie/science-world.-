import pathlib, re
p = pathlib.Path('android/app/src/main/AndroidManifest.xml')
s = p.read_text(encoding='utf-8')
if 'android.permission.INTERNET' not in s:
    s = s.replace('<application', '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
if '<queries>' not in s:
    s = s.replace('</manifest>', '    <queries>\n        <package android:name="com.whatsapp"/>\n        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>\n    </queries>\n</manifest>')
s = re.sub(r'android:label="[^"]*"', 'android:label="عالم العلوم"', s, count=1)
p.write_text(s, encoding='utf-8')
print('manifest patched')
