import 'package:flutter_test/flutter_test.dart';
import 'package:science_world/data/models/question.dart';
import 'package:science_world/features/quiz/quiz_controller.dart';

Question mcq(String id) => Question(
    id: id, grade: 9, subject: 's', lesson: 'l', type: QuestionType.mcq,
    difficulty: Difficulty.easy, text: 't', options: const ['a', 'b'], correct: '1');

void main() {
  test('first answer locks; repeated taps ignored', () {
    final c = QuizController([mcq('1'), mcq('2')]);
    expect(c.submit('1'), AnswerState.correct);
    expect(c.submit('0'), AnswerState.correct);
  });
  test('result counts correct/wrong/skipped', () {
    final c = QuizController([mcq('1'), mcq('2'), mcq('3')]);
    c.submit('1');
    c.next();
    c.submit('0');
    final r = c.result();
    expect((r.correct, r.wrong, r.skipped), (1, 1, 1));
    expect(r.percent.round(), 33);
  });
}
