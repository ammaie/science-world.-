import 'package:flutter_test/flutter_test.dart';
import 'package:science_world/data/models/question.dart';
import 'package:science_world/data/models/import_validator.dart';
import 'package:science_world/core/whatsapp.dart';

Map<String, dynamic> row(String id, {String? correct = '1', String origin = 'practice', String? source}) => {
      'id': id, 'grade': 9, 'subject': 'x', 'lesson': 'l', 'type': 'mcq', 'difficulty': 'easy',
      'text': 'سؤال $id', 'options': ['a', 'b'], 'correct': correct, 'origin': origin, 'source': source,
    };

void main() {
  test('numeric check', () {
    final q = Question.fromJson({...row('1'), 'type': 'numeric', 'correct': '36'});
    expect(q.check('36.0'), true);
    expect(q.check('35'), false);
  });
  test('written is self-review', () {
    final q = Question.fromJson({...row('2'), 'type': 'written', 'correct': null, 'rubric': 'r'});
    expect(q.check('x'), isNull);
    expect(q.isComplete, true);
  });
  test('import validator catches duplicates, incomplete, unsourced official', () {
    final r = validateQuestions([
      row('a'), row('a'), row('b', correct: null), row('c', origin: 'official'),
      row('d', origin: 'official', source: 'url'),
    ]);
    expect(r.accepted.map((e) => e.id), ['a', 'd']);
    expect(r.duplicates, ['a']);
    expect(r.incomplete, ['b']);
    expect(r.errors.length, 1);
  });
  test('whatsapp uri', () {
    final u = buildWhatsappUri('+90 538 956 7265');
    expect(u.host, 'wa.me');
    expect(u.path, '/905389567265');
    expect(u.queryParameters['text'], isNotEmpty);
  });
}
