مجلد android يُولَّد بالأمر: flutter create --platforms=android --org com.scienceworld --project-name science_world .
(يفعل ذلك سير عمل GitHub تلقائيًا إن لم يكن موجودًا، ثم يبني APK.)
بعد التوليد المحلي أو بعد أول بناء ناجح، أضف مجلد android الكامل إلى المستودع.
